package com.nihal.FileShare.exception;

/**
 * created by: Veli
 * date: 6.01.2018 22:25
 */

public class ConnectionNotFoundException extends NotFoundException
{
}
