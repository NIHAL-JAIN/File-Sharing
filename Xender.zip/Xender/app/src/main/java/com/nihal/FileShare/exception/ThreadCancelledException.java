package com.nihal.FileShare.exception;

public class ThreadCancelledException extends Exception
{
}
