package com.nihal.FileShare.exception;

/**
 * created by: veli
 * date: 8/26/18 10:48 PM
 */
public class NotReadyException extends Exception
{
    public NotReadyException(String msg)
    {
        super(msg);
    }
}
