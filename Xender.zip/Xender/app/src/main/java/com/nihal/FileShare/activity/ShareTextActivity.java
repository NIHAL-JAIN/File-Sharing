package com.nihal.FileShare.activity;

import com.nihal.FileShare.app.Activity;

public class ShareTextActivity extends Activity
{
}
