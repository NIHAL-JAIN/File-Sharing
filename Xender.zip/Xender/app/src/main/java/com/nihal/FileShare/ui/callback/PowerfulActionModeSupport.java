package com.nihal.FileShare.ui.callback;

import com.genonbeta.android.framework.widget.PowerfulActionMode;

/**
 * created by: Veli
 * date: 19.11.2017 18:07
 */

public interface PowerfulActionModeSupport
{
    PowerfulActionMode getPowerfulActionMode();
}
